
		
 <!-- Main content -->
    <section class="content">

     
      <div class="row">
	      <div class="col-md-3 col-sm-6 col-xs-12">
		  <a href="home.php?page=ssh/online">
          <div class="info-box">
            <span class="info-box-icon bg-blue"><i class="fa fa-tv"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Ver Users Online</span>
            </div>
             <!--/.info-box-content -->
          </div>
          </a>
        </div>
		    
	  
	     <div class="col-md-3 col-sm-6 col-xs-12">
		  <a href="home.php?page=servidor/adicionar">
          <div class="info-box">
            <span class="info-box-icon bg-blue"><i class="fa fa-cloud"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Add Servidor</span>
            </div>
            <!-- /.info-box-content -->
          </div>
           </a>
        </div>
		
        
		
		  <div class="col-md-3 col-sm-6 col-xs-12">
          <a href="home.php?page=ssh/contas">
		 <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-globe"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Contas OVPN</span>
              <span class="info-box-number"><?php echo $total_acesso_ssh;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
        </div>
		
		<div class="col-md-3 col-sm-6 col-xs-12">
          <a href="home.php?page=ssh/adicionar">
		  <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-check-square"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">ADD Conta OVPN</span>
            </div>
            <!-- /.info-box-content -->
          </div>
         </a>
        </div>
		
		



        <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="home.php?page=usuario/usuario_ssh">
     <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-user"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Usu&aacute;rios</span>
              <span class="info-box-number"><?php echo $all_usuarios_vpn_qtd;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
            </a>
        </div>



        <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="home.php?page=usuario/1-etapa">
     <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-check-square"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">ADD Usu&aacute;rio</span>
            </div>
            <!-- /.info-box-content -->
          </div>
            </a>
        </div>


		
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="home.php?page=usuario/revenda">
		 <div class="info-box">
            <span class="info-box-icon bg-orange"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Revendedores</span>
              <span class="info-box-number"><?php echo $all_usuarios_revenda_qtd;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
        </div>




        <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="home.php?page=ssh/contas">
     <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-globe"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Contas OVPN Susp.</span>
              <span class="info-box-number"><?php echo $ssh_susp_qtd;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
          </a>
        </div>



        <div class="col-md-3 col-sm-6 col-xs-12">
      <a href="home.php?page=usuario/usuario_ssh">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-user"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Usu&aacute;rios Susp.</span>
              <span class="info-box-number"><?php echo $all_usuarios_vpn_qtd_susp;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
         </a>
        </div>


		
		<div class="col-md-3 col-sm-6 col-xs-12">
		<a href="home.php?page=usuario/revenda">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Revendedores Susp.</span>
              <span class="info-box-number"><?php echo $revenda_qtd_susp;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
            </a>
        </div>
		
		
		
			
      
      </div>
      <!-- /.row -->

       <!-- /.row -->

     
      <!-- /.row -->



    
    

    </section>
    <!-- /.content -->
  </div>