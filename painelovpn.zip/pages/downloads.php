
 <!-- Main content -->
    <section class="content">

      <div class="row">
	   
    
    <!--Voltar Para HOME-->        
    <div class="col-md-3 col-sm-6 col-xs-12">
     <a href="?home.php"> 
      <div class="info-box">
        <span class="info-box-icon bg-blue"><i class="fa fa-home"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Home</span>
        </div>
        <!-- /.info-box-content -->
      </div>
     </a> 
      <!-- /.info-box -->
    </div>
    <!--/Volta Para HOME-->




    <!--Download do Arquivo .ovpn-->
    <div class="col-md-3 col-sm-6 col-xs-12">
     <a href="http://MEU-IP/downloads/NOME-DO-ARQUIVO-SEM-ESPAÇOS" download="" "> 
      <div class="info-box">
        <span class="info-box-icon bg-blue"><i class="fa fa-file"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">VPS1-OVPN</span>
        </div>
        <!-- /.info-box-content -->
      </div>
     </a> 
      <!-- /.info-box -->
    </div>
    <!--/Download do Arquivo .ovpn-->

      





      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>