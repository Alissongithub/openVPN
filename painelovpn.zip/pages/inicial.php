
 <!-- Main content -->
    <section class="content">

      <div class="row">
	   
            

    <div class="col-md-3 col-sm-6 col-xs-12">
     <a href="?page=ssh/online"> 
      <div class="info-box">
        <span class="info-box-icon bg-blue"><i class="fa fa-tv"></i></span>
        <div class="info-box-content">
          <span class="info-box-text">Users Onlines</span>
        </div>
        <!-- /.info-box-content -->
      </div>
     </a> 
      <!-- /.info-box -->
    </div>


			
		<div class="col-md-3 col-sm-6 col-xs-12">
        <a href="?page=ssh/contas">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-globe"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Contas OVPN</span>
              <span class="info-box-number"><?php echo $quantidade_ssh; ?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
        </a>  <!-- /.info-box -->
        </div>
	
			<?php if(($usuario['tipo']=="revenda") and ($acesso_servidor > 0) ){?>
        <div class="col-md-3 col-sm-6 col-xs-12">
        <a href="?page=ssh/adicionar">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa  fa-check-square"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Add Conta OVPN</span>
            </div>
            <!-- /.info-box-content -->
          </div>
        </a>  
          <!-- /.info-box -->
        </div>
      <?php }?>


          <!-- /.col -->
        <?php if($usuario['tipo']=="revenda"){?>
            <div class="col-md-3 col-sm-6 col-xs-12">
             <a href="?page=usuario/listar"> 
              <div class="info-box">
                <span class="info-box-icon bg-green"><i class="fa fa-users"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">Usuários</span>
                  <span class="info-box-number"><?php echo $quantidade_sub; ?></span>
                </div>
                <!-- /.info-box-content -->
              </div>
             </a> 
              <!-- /.info-box -->
            </div>  
        <?php }?>    

		<?php if(($usuario['tipo']=="revenda") and ($acesso_servidor > 0) ){?>
		   <div class="col-md-3 col-sm-6 col-xs-12">
         <a href="?page=usuario/adicionar"> 
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-check-square"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Add Usuário</span>
            </div>
            <!-- /.info-box-content -->
          </div>
         </a> 
          <!-- /.info-box -->
        </div>


		
		<div class="col-md-3 col-sm-6 col-xs-12">
        <a href="?page=ssh/contas">  
          <div class="info-box"> 
            <span class="info-box-icon bg-red"><i class="fa fa-globe"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Contas OVPN Susp.</span>
              <span class="info-box-number"><?php echo $all_ssh_susp_qtd;?></span>
            </div>
            <!-- /.info-box-content -->
          </div>
        </a>  
		  </div>
    
	  




            <div class="col-md-3 col-sm-6 col-xs-12">
             <a href="?page=downloads"> 
              <div class="info-box">
                <span class="info-box-icon bg-orange"><i class="fa fa-download"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text">Downloads</span>
                </div>
                <!-- /.info-box-content -->
              </div>
             </a> 
              <!-- /.info-box -->
            </div>

		
		
		<?php }?>
      
      </div>
      <!-- /.row -->

     



    
    

    </section>
    <!-- /.content -->
  </div>